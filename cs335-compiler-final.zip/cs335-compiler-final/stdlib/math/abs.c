int abs(int val){
	if(val < 0)
		return -val;
	return val;
}

float abs(float val){
	if(val < 0)
		return -val;
	return val;
}
