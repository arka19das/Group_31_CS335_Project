class default_op:
    def add_int(id1, id2):
        pass

    def add_long(id1, id2):
        pass

    def add_ll(id1, id2):
        pass

    def add_float(id1, id2):
        pass

    def add_double(id1, id2):
        pass

    def mul_int(id1, id2):
        pass

    def mul_long(id1, id2):
        pass

    def mul_ll(id1, id2):
        pass

    def mul_float(id1, id2):
        pass

    def mul_double(id1, id2):
        pass

    def div_int(id1, id2):
        pass

    def div_long(id1, id2):
        pass

    def div_ll(id1, id2):
        pass

    def div_float(id1, id2):
        pass

    def div_double(id1, id2):
        pass

    def mod_int(id1, id2):
        pass

    def mod_long(id1, id2):
        pass

    def mod_ll(id1, id2):
        pass
