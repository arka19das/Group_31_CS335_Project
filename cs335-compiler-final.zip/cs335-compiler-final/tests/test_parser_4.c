// testing loops
int main()
{
    int i = 0;
    // int n = 10;
    int sum = 0;
    double z = 10.0;
    // signed int d = 2;
    for (i = 1; i< 10; i ++)
    {
        sum = sum + i;
    }

    // while (i>0)
    // {
    //     i--;
    //     sum -= i;
    // }
    return 0;
}