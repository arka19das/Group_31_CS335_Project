// Sizeof demo

int main() {
    int a, d;
    double b;

    int x;
    struct x {
        float y, z;
    };
    struct x obj;

    x = sizeof(int);
    d = sizeof b;
    a = sizeof(int*);


    return a;
}