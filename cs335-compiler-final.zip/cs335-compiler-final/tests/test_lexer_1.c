int main() {
	if(c==0) {
		c++;
	if(a==b)
		a++;}
	else
		b++;
}
