// Copy Propagation

int d;

int main() {
    int x;
    x = x + d;
    return x;
}