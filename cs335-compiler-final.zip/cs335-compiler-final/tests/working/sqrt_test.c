@include "stdlib/math/sqrt.c"
@include "stdlib/io/console_output.c"

int main(){

    float sqroot;
    sqroot = sqrt(17.0);
    print_float(sqroot);

    return 0;
}