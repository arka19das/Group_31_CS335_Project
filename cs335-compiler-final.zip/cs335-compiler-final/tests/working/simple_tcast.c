int main() {
    int a, c;
    float b = 3.1;
    a = (int) 4.5;
    c = (int) b;
    return a + c;
}