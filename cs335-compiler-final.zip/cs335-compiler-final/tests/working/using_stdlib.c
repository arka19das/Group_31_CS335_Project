@include "stdlib/math/pow.c"

int main() {
    return (int)pow(3.0, 3) + pow(10, 3);
}