void karray(int c, double s) {
    static double k;
    k = 1.0;
    return;
}


int main() {
    static int k;
    int c = 2, a, b;
    double z;
    // a = &c;
    // *c = 2;
	if(a==0) {
		c++;
        if(a==b)
            z = (1 == 1 ? a : b);
        z++;
    }
	else
		b++;

    k += 1;

	switch(c)
    {
        case 1:
            a--;
            1 + 1;
            break;

        case 2:
            z = a+b;
            break;

        default:
            c++;
    }

    return 0;
}
