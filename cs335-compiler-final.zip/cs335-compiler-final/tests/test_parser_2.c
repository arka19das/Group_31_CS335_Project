// Function to print an array
void printArray(int arr2[], int size)
{
    int i = 9;
    // double size2;
    double c = 6.0;
    for (i=0; i < size; i++); 
    // {
    //     // printf("%d ", arr[i]);
    // }
    // printf("\n");
}
 
// Driver program to test above functions
int main()
{
    int arr[10][2][5] = {{{1,2},{12,3}}};
    int size;
    int n;
    // int x = arr[2];
    printArray(arr, n);
    return 0;
}